from flask import Flask, request, render_template, send_file
import os
import subprocess
import uuid

app = Flask(__name__)
DOWNLOAD_FOLDER = "downloads"

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        url = request.form["url"]
        filename = str(uuid.uuid4())
        output_path = os.path.join(DOWNLOAD_FOLDER, filename)

        # Ejecutar SpotDL
        command = [
            "spotdl",
            url,
            "--output",
            output_path
        ]
        try:
            subprocess.run(command, check=True)
            mp3_file = output_path + ".mp3"
            return send_file(mp3_file, as_attachment=True)
        except subprocess.CalledProcessError:
            return "Hubo un error al descargar la canción."

    return render_template("index.html")

if __name__ == "__main__":
    if not os.path.exists(DOWNLOAD_FOLDER):
        os.makedirs(DOWNLOAD_FOLDER)
    app.run(debug=True)
